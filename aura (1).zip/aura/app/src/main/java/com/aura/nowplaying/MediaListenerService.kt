package com.aura.nowplaying

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.KeyguardManager
import android.content.IntentFilter
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.service.notification.NotificationListenerService
import androidx.core.content.ContextCompat

/**
 * Servicio que Android mantiene vivo cuando le das "Acceso a notificaciones".
 * Gracias a él podemos ver qué está sonando y detectar cuando desbloqueas el teléfono.
 */
class MediaListenerService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var registered = false
    /** Ya se mostró en este encendido de pantalla (para no repetir al desbloquear). */
    private var shownThisCycle = false

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { _: List<MediaController>? ->
        MediaRepo.refresh(this)
    }

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_ON -> onScreenOn()
                Intent.ACTION_SCREEN_OFF -> shownThisCycle = false
                Intent.ACTION_USER_PRESENT -> onUnlocked()
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (registered) return
        registered = true
        try {
            getSystemService(MediaSessionManager::class.java)?.addOnActiveSessionsChangedListener(
                sessionsListener, ComponentName(this, MediaListenerService::class.java), handler
            )
        } catch (_: SecurityException) {
        }
        ContextCompat.registerReceiver(
            this, unlockReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        MediaRepo.refresh(this)
    }

    override fun onListenerDisconnected() {
        cleanup()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        if (!registered) return
        registered = false
        try {
            getSystemService(MediaSessionManager::class.java)?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {
        }
        try {
            unregisterReceiver(unlockReceiver)
        } catch (_: Exception) {
        }
    }

    /** Pantalla encendida y todavía bloqueada: Aura aparece sobre la pantalla de bloqueo. */
    private fun onScreenOn() {
        val mode = Prefs.mode(this)
        if (mode != Prefs.MODE_LOCK && mode != Prefs.MODE_BOTH) return
        val km = getSystemService(KeyguardManager::class.java)
        if (km?.isKeyguardLocked != true) return
        show(delayMs = 60)
    }

    /** Ya desbloqueado (comportamiento original de Aura). */
    private fun onUnlocked() {
        val mode = Prefs.mode(this)
        if (mode != Prefs.MODE_UNLOCK && mode != Prefs.MODE_BOTH) return
        // Si ya se mostró en la pantalla de bloqueo, o sigue visible, no se repite
        if (shownThisCycle || NowPlayingActivity.visible) return
        // Pequeña pausa para que termine la animación de desbloqueo del sistema
        show(delayMs = 250)
    }

    private fun show(delayMs: Long) {
        if (!Prefs.enabled(this)) return
        // Solo se usa para que Android permita abrir la pantalla desde segundo plano.
        // Aura NO dibuja encima: es una pantalla normal marcada como "mostrar sobre el bloqueo".
        if (!Settings.canDrawOverlays(this)) return
        MediaRepo.refresh(this)
        if (!MediaRepo.isPlaying()) return
        shownThisCycle = true
        handler.postDelayed({
            val i = Intent(this, NowPlayingActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            try {
                startActivity(i)
            } catch (_: Exception) {
            }
        }, delayMs)
    }
}
